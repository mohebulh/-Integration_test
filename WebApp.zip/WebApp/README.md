# se-git-demo
Demonstration on how to use git collaboratively

Add a change
Another change
change more things
Add another change
